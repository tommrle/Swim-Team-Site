<html>
<head>
<link rel="stylesheet" style="text/css" href="swimteam.css">
</head>

<body>
<div class='mainbox'>
<?php include 'header.php' ?>

<?php include 'navigation.php'; ?>
<br><br>
<font size=18 id='title'>Team Information</font>
<div id='underline'></div>
<br>
2012 Season Information:<br>
<a href='SeasonStartPacket2012.doc'>Information Packet</a>
<br><br>
other stuff
</div>
</body>
</html>