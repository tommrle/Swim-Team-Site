/*
 <style type="text/css">
 
 #navlist{position:relative;}
 #navlist li{margin:0;padding:0;list-style:none;position:absolute;top:0;}
 #navlist li, #navlist a{height:90px;display:block;}
 
 li#top
 {
 left:0px;
 width:200px;
 height:75px;
 background:url('NavTopv2.png') 0 0;
 }
 
 li#home
 {
 left:0px;
 width:200px;
 height:49px;
 background:url(buttonsv3.png) 0 0;
 }
 
 li#home a:hover
 {
 left:0px;
 width:200px;
 height:49px;
 background:url(buttonsv3.png) 200px 0;
 }
 
 li#Calendar
 {
 top:50px;
 left:0px;
 width:200px;
 height:50px;
 background:url(buttonsv3.png) 0px -50px;
 }
 
 li#Calendar a:hover
 {
 top:50px;
 left:0px;
 width:200px;
 height:50px;
 background:url(buttonsv3.png) 200px -50px;
 }
 
 li#Directions
 {
 top:101px;
 left:0px;
 width:200px;
 height:50px;
 background:url(buttonsv3.png) 0px -103px;
 }
 
 li#Directions a:hover
 {
 top:101px;
 left:0px;
 width:200px;
 height:50px;
 background:url(buttonsv3.png) 200px -103px;
 }
 
 <img src='NavTopv2.png' height=75px width=200px;> 
 <li id='top'></li><br> 
 </style>
 <ul id='navlist'>
 
 <li id='home'><a href='welcome.php'></a></li>
 <li id='Calendar'><a href='calendar.php'></a></li>
 <li id='Directions'><a href='directions.php'></a></li>
 
 </ul>
 */
