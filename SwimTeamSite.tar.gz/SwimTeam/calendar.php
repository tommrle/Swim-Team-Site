<html>
<head>
<link rel="stylesheet" style="text/css" href="swimteam.css">
</head>

<body>
<div class='mainbox'>
<?php include 'header.php' ?>

<?php include 'navigation.php'; ?>
<br><br>
<font size=18 id='title'>2012 Season Calendar</font>
<div id='underline'></div>
<br>
Click to view full size<br>
June<br>
<a href='June Cal v4.png'><img src='June Cal v4.png' width=350px /></a>
<br><br>
July<br>
<a href='July Cal v4.png'><img src='July Cal v4.png' width=350px /></a>

</div>
</body>
</html>